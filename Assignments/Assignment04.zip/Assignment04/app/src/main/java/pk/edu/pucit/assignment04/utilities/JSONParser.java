package pk.edu.pucit.assignment04.utilities;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import pk.edu.pucit.assignment04.model.Movie;

public class JSONParser {

    public static ArrayList<Movie> parseMoviesData(String jsonResponse) {
        ArrayList<Movie> movies = null;
        try {
            JSONObject root = new JSONObject(jsonResponse);
            JSONArray results = root.getJSONArray(Constant.TAG_RESULTS);
            movies = new ArrayList<>();
            for (int i = 0; i < results.length(); i++) {
                JSONObject result = results.getJSONObject(i);
                Movie movie = new Movie();
                movie.setTitle(result.getString(Constant.TAG_TITLE));
                movie.setOverview(result.getString(Constant.TAG_OVERVIEW));
                movie.setImage(result.getString(Constant.TAG_POSTER_PATH));
                movie.setReleaseDate(result.getString(Constant.TAG_RELEASE_DATE));
                movie.setVoteAverage(result.getString(Constant.TAG_VOTE_AVERAGE));
                movies.add(movie);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return movies;
    }

}
