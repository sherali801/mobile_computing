package pk.edu.pucit.assignment04;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import pk.edu.pucit.assignment04.model.Movie;

public class MovieDetailActivity extends AppCompatActivity {

    private ImageView imageViewPosterActivityMovieDetail;
    private TextView textViewTitleActivityMovieDetail, textViewReleaseDateActivityMovieDetail, textViewOverviewActivityMovieDetail, textViewVotingAverageActivityMovieDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);
        initialize();
        populateView();
    }

    private void initialize() {
        imageViewPosterActivityMovieDetail = findViewById(R.id.image_view_poster_activity_movie_detail);
        textViewTitleActivityMovieDetail = findViewById(R.id.text_view_title_activity_movie_detail);
        textViewReleaseDateActivityMovieDetail = findViewById(R.id.text_view_release_date_activity_movie_detail);
        textViewOverviewActivityMovieDetail = findViewById(R.id.text_view_overview_activity_movie_detail);
        textViewVotingAverageActivityMovieDetail = findViewById(R.id.text_view_voting_average_activity_movie_detail);
    }

    private void populateView() {
        Movie movie = (Movie) getIntent().getExtras().getSerializable("movie");
        Glide.with(this).load("https://image.tmdb.org/t/p/w500/" + movie.getImage()).into(imageViewPosterActivityMovieDetail);
        textViewTitleActivityMovieDetail.setText(movie.getTitle());
        textViewReleaseDateActivityMovieDetail.setText(movie.getReleaseDate());
        textViewOverviewActivityMovieDetail.setText(movie.getOverview());
        textViewVotingAverageActivityMovieDetail.setText(movie.getVoteAverage());
    }

}
