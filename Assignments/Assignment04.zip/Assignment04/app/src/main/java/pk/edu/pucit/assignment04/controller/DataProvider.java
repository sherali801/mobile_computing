package pk.edu.pucit.assignment04.controller;

import java.util.ArrayList;

import pk.edu.pucit.assignment04.model.Movie;
import pk.edu.pucit.assignment04.model.Response;
import pk.edu.pucit.assignment04.utilities.Constant;
import pk.edu.pucit.assignment04.utilities.HttpHelper;
import pk.edu.pucit.assignment04.utilities.JSONParser;

public class DataProvider {

    public static Response getMoviesData() {
        String jsonResponse = HttpHelper.downloadUrl(Constant.JSON_URL);
        Response response = null;
        if (jsonResponse != null) {
            ArrayList<Movie> movies = JSONParser.parseMoviesData(jsonResponse);
            response = new Response();
            response.setMovies(movies);
        }
        return response;
    }

}
