package pk.edu.pucit.assignment04.utilities;

public class Constant {

    public static final String JSON_URL = "https://api.themoviedb.org/3/movie/popular?api_key=cd1c6180346bde7bab3b141ac5d3effb&language=en-US&page=1";

    public static final String TAG_RESULTS = "results";
    public static final String TAG_TITLE = "title";
    public static final String TAG_OVERVIEW = "overview";
    public static final String TAG_POSTER_PATH = "poster_path";
    public static final String TAG_RELEASE_DATE = "release_date";
    public static final String TAG_VOTE_AVERAGE = "vote_average";

}
