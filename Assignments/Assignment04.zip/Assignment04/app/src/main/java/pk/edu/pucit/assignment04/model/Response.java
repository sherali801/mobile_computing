package pk.edu.pucit.assignment04.model;

import java.util.ArrayList;

public class Response {

    private ArrayList<Movie> movies = null;

    public ArrayList<Movie> getMovies() {
        return movies;
    }

    public void setMovies(ArrayList<Movie> movies) {
        this.movies = movies;
    }

}
