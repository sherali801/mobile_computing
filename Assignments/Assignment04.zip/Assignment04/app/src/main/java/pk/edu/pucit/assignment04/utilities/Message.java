package pk.edu.pucit.assignment04.utilities;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;

public class Message {

    public static void showDialog(final Context context, int message, int positive) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(message);
        builder.setPositiveButton(positive, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int id) {
                ((Activity) context).finish();
            }
        });
        builder.show();
    }


}
