package pk.edu.pucit.assignment04;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;

import java.util.ArrayList;

import pk.edu.pucit.assignment04.adapter.MoviesAdapter;
import pk.edu.pucit.assignment04.controller.DataProvider;
import pk.edu.pucit.assignment04.model.Movie;
import pk.edu.pucit.assignment04.model.Response;
import pk.edu.pucit.assignment04.utilities.Message;
import pk.edu.pucit.assignment04.utilities.NetworkHelper;

public class MainActivity extends AppCompatActivity {

    private boolean networkAccess;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private ArrayList<Movie> movies;
    private MoviesAdapter moviesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
        networkAccess = NetworkHelper.networkAccess(this);
        if (networkAccess) {
            (new MoviesAsyncTask()).execute();
        } else {
            Message.showDialog(this, R.string.no_internet_connection, R.string.ok);
        }
    }

    private void initialize() {
        progressBar = findViewById(R.id.progress_bar_loading_activity_main);
        recyclerView = findViewById(R.id.recycler_view_movies_activity_main);
    }

    private class MoviesAsyncTask extends AsyncTask<Void, Void, Response> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected Response doInBackground(Void... voids) {
            return DataProvider.getMoviesData();
        }

        @Override
        protected void onPostExecute(Response response) {
            super.onPostExecute(response);
            progressBar.setVisibility(View.INVISIBLE);
            if (response == null || response.getMovies() == null || response.getMovies().isEmpty()) {
                Message.showDialog(MainActivity.this, R.string.no_movie_found, R.string.ok);
            } else {
                movies = response.getMovies();
                moviesAdapter = new MoviesAdapter(MainActivity.this, movies);
                recyclerView.setAdapter(moviesAdapter);
                moviesAdapter.notifyDataSetChanged();
            }
        }

    }

}
