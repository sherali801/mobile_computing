package pk.edu.pucit.assignment04.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import pk.edu.pucit.assignment04.MovieDetailActivity;
import pk.edu.pucit.assignment04.R;
import pk.edu.pucit.assignment04.model.Movie;

public class MoviesAdapter extends RecyclerView.Adapter<MoviesAdapter.MovieViewHolder> {

    private Context context;
    private List<Movie> movies;

    public class MovieViewHolder extends RecyclerView.ViewHolder {

        public ImageView imageViewPosterActivityMain;
        public TextView textViewTitleActivityMain;

        public MovieViewHolder(View view) {
            super(view);
            imageViewPosterActivityMain = view.findViewById(R.id.image_view_poster_activity_main);
            textViewTitleActivityMain = view.findViewById(R.id.text_view_title_activity_main);
        }
    }

    public MoviesAdapter(Context context, List<Movie> movies) {
        this.context = context;
        this.movies = movies;
    }

    @Override
    public MovieViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.movie_cell, parent, false);
        return new MovieViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MovieViewHolder movieViewHolder, int position) {
        final Movie movie = movies.get(position);
        movieViewHolder.textViewTitleActivityMain.setText(movie.getTitle());
        Glide.with(context).load("https://image.tmdb.org/t/p/w500/" + movie.getImage()).into(movieViewHolder.imageViewPosterActivityMain);
        movieViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, MovieDetailActivity.class);
                intent.putExtra("movie", movie);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return movies.size();
    }

}

