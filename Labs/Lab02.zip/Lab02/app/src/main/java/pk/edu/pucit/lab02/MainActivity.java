package pk.edu.pucit.lab02;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText editTextName, editTextFatherName, editTextAddress, editTextAge, editTextGender, editTextDOB, editTextCity, editTextDistrict, editTextPhoneNo, editTextEmail, editTextDepartment;
    Button button_done;
    TextView textViewShow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.edit_text_name_activity_main);
        editTextFatherName = findViewById(R.id.edit_text_father_name_activity_main);
        editTextAddress = findViewById(R.id.edit_text_address_activity_main);
        editTextAge = findViewById(R.id.edit_text_age_activity_main);
        editTextGender = findViewById(R.id.edit_text_gender_activity_main);
        editTextDOB = findViewById(R.id.edit_text_dob_activity_main);
        editTextCity = findViewById(R.id.edit_text_city_activity_main);
        editTextDistrict = findViewById(R.id.edit_text_district_activity_main);
        editTextPhoneNo = findViewById(R.id.edit_text_phone_no_activity_main);
        editTextEmail = findViewById(R.id.edit_text_email_activity_main);
        editTextDepartment = findViewById(R.id.edit_text_department_activity_main);

        button_done = findViewById(R.id.button_done_activity_main);
        button_done.setOnClickListener(this);

        textViewShow = findViewById(R.id.text_view_show_activity_main);

    }

    @Override
    public void onClick(View v) {
        Student student = new Student(editTextName.getText().toString(), editTextFatherName.getText().toString(), editTextAddress.getText().toString(), Integer.parseInt(editTextAge.getText().toString()), editTextGender.getText().toString(), editTextDOB.getText().toString(), editTextCity.getText().toString(), editTextDistrict.getText().toString(), editTextPhoneNo.getText().toString(), editTextEmail.getText().toString(), editTextDepartment.getText().toString());

        textViewShow.setText(student.name + "\npersonal info is:\nFather Name" + student.fatherName + "\nAddress: " + student.address + "\nAge: " + student.age + "\nGender: " + student.gender + "\nDOB: " + student.dob + "\nCity: " + student.city + "\nDistrict: " + student.district + "\nPhone No.: " + student.phoneNo + "\nEmail: " + student.email + "\nDepartment: " + student.department);
    }

    public boolean isEmpty(String str) {
        return str.length() == 0 ? true : false;
    }
}
