package pk.edu.pucit.lab02;

public class Student {
    public String name;
    public String fatherName;
    public String address;
    public int age;
    public String gender;
    public String dob;
    public String city;
    public String district;
    public String phoneNo;
    public String email;
    public String department;

    public Student(String name, String fatherName, String address, int age, String gender, String dob, String city, String district, String phoneNo, String email, String department) {
        this.name = name;
        this.fatherName = fatherName;
        this.address = address;
        this.age = age;
        this.gender = gender;
        this.dob = dob;
        this.city = city;
        this.district = district;
        this.phoneNo = phoneNo;
        this.email = email;
        this.department = department;
    }
}
