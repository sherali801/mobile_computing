package pk.edu.pucit.lab06;


import android.arch.lifecycle.Observer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import pk.edu.pucit.lab06.database.Database;
import pk.edu.pucit.lab06.entity.TeacherEntity;


/**
 * A simple {@link Fragment} subclass.
 */
public class TeacherFragment extends Fragment {

    private TextView textViewDisplayTeachersFragmentTeacher;

    public TeacherFragment() {
        // Required empty public constructor
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        textViewDisplayTeachersFragmentTeacher = getView().findViewById(R.id.text_view_display_teachers_fragment_teacher);
        Database.getInstance(getActivity()).teacherDao().getAllTeachers().observe(this, new Observer<List<TeacherEntity>>() {
            @Override
            public void onChanged(@Nullable List<TeacherEntity> teachers) {
                textViewDisplayTeachersFragmentTeacher.setText("");
                for (TeacherEntity teacher : teachers) {
                    textViewDisplayTeachersFragmentTeacher.append(teacher.getName() + ", " + teacher.getEmail() + "\n");
                }
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_teacher, container, false);
    }

}
