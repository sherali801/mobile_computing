package pk.edu.pucit.lab06.dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import java.util.List;

import pk.edu.pucit.lab06.entity.StudentEntity;

@Dao
public abstract interface StudentDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addNewStudent(StudentEntity student);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addNewStudents(StudentEntity... student);

    @Query("SELECT * FROM student")
    LiveData<List<StudentEntity>> getAllStudents();

    @Query("DELETE FROM student")
    void deleteAll();

}
