package pk.edu.pucit.lab06.dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import java.util.List;

import pk.edu.pucit.lab06.entity.TeacherEntity;

@Dao
public abstract interface TeacherDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addNewTeacher(TeacherEntity teacher);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addNewTeachers(TeacherEntity... teacher);

    @Query("SELECT * FROM teacher")
    LiveData<List<TeacherEntity>> getAllTeachers();

    @Query("DELETE FROM teacher")
    void deleteAll();

}
