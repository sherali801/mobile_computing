package pk.edu.pucit.lab06;


import android.arch.lifecycle.Observer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import pk.edu.pucit.lab06.database.Database;
import pk.edu.pucit.lab06.entity.StudentEntity;


/**
 * A simple {@link Fragment} subclass.
 */
public class StudentFragment extends Fragment {

    private TextView textViewDisplayStudentsFragmentStudent;

    public StudentFragment() {
        // Required empty public constructor
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        textViewDisplayStudentsFragmentStudent = getView().findViewById(R.id.text_view_display_students_fragment_student);
        Database.getInstance(getActivity()).studentDao().getAllStudents().observe(this, new Observer<List<StudentEntity>>() {
            @Override
            public void onChanged(@Nullable List<StudentEntity> students) {
                textViewDisplayStudentsFragmentStudent.setText("");
                for (StudentEntity student : students) {
                    textViewDisplayStudentsFragmentStudent.append(student.getName() + ", " + student.getEmail() + "\n");
                }
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_student, container, false);
    }

}
