package pk.edu.pucit.lab06.database;

import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import pk.edu.pucit.lab06.dao.StudentDao;
import pk.edu.pucit.lab06.dao.TeacherDao;
import pk.edu.pucit.lab06.entity.StudentEntity;
import pk.edu.pucit.lab06.entity.TeacherEntity;

@android.arch.persistence.room.Database(entities = {TeacherEntity.class, StudentEntity.class}, version = 2)
public abstract class Database extends RoomDatabase {

    private static final String DATABASE_NAME = "database";
    private static Database instance = null;

    public abstract TeacherDao teacherDao();
    public abstract StudentDao studentDao();

    public static Database getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context, Database.class, DATABASE_NAME)
                    .allowMainThreadQueries()
                    .build();
        }
        return instance;
    }

}
