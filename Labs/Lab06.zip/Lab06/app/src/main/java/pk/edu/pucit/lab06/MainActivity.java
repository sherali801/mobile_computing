package pk.edu.pucit.lab06;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import pk.edu.pucit.lab06.dao.StudentDao;
import pk.edu.pucit.lab06.dao.TeacherDao;
import pk.edu.pucit.lab06.database.Database;
import pk.edu.pucit.lab06.entity.StudentEntity;
import pk.edu.pucit.lab06.entity.TeacherEntity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button buttonDisplayTeachersActivityMain, buttonDisplayStudentsActivityMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        populateDatabase();
        initialize();
    }

    private void initialize() {
        buttonDisplayTeachersActivityMain = findViewById(R.id.button_display_teachers_activity_main);
        buttonDisplayStudentsActivityMain = findViewById(R.id.button_display_stuents_activity_main);
        buttonDisplayTeachersActivityMain.setOnClickListener(this);
        buttonDisplayStudentsActivityMain.setOnClickListener(this);
    }

    private void populateDatabase() {
        Database database = Database.getInstance(this);
        TeacherDao teacherDao = database.teacherDao();
        StudentDao studentDao = database.studentDao();

        teacherDao.deleteAll();
        studentDao.deleteAll();

        TeacherEntity teacher1 = new TeacherEntity("Anum Tariq Butt", "anum@gmail.com");
        TeacherEntity teacher2 = new TeacherEntity("Nazar Amin Khan", "nazar@gmail.com");
        TeacherEntity teacher3 = new TeacherEntity("Tariq Butt", "tariq@gmai.com");
        TeacherEntity teacher4 = new TeacherEntity("Madiha Saleem", "madiha@gmail.com");

        teacherDao.addNewTeachers(teacher1, teacher2, teacher3, teacher4);

        StudentEntity student1 = new StudentEntity("Sher Ali", "sher@gmail.com");
        StudentEntity student2 = new StudentEntity("Muneeb Ul Hassan", "muneeb@gmail.com");
        StudentEntity student3 = new StudentEntity("Ahmad Javaid", "ahmad@gmail.com");
        StudentEntity student4 = new StudentEntity("Moiz Hussain", "moiz@gmail.com");

        studentDao.addNewStudents(student1, student2, student3, student4);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_display_teachers_activity_main:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frame_layout_container_activity_main, new TeacherFragment())
                        .commit();
                break;
            case R.id.button_display_stuents_activity_main:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frame_layout_container_activity_main, new StudentFragment())
                        .commit();
                break;
        }
    }

}
