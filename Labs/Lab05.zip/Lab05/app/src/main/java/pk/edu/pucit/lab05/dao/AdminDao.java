package pk.edu.pucit.lab05.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import pk.edu.pucit.lab05.entity.Admin;

@Dao
public interface AdminDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addNewAdmin(Admin admin);

    @Query("SELECT * FROM admin a, user u WHERE a.user_id = u.id AND u.id = :userId ")
    Admin getAdminByUserId(long userId);

    @Query("DELETE FROM admin")
    void deleteAll();

}
