package pk.edu.pucit.lab05;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import pk.edu.pucit.lab05.database.AppDatabase;
import pk.edu.pucit.lab05.entity.Teacher;
import pk.edu.pucit.lab05.entity.User;

public class NewTeacherActivity extends AppCompatActivity {

    private EditText editTextLoginActivityNewTeacher, editTextPasswordActivityNewTeacher, editTextNameActivityNewTeacher, editTextSubjectActivityNewTeacher, editTextEmailActivityNewTeacher, editTextPhoneNoActivityNewTeacher;
    private Button buttonSubmitActivityNewTeacher;
    private String login, password, name, subject, email, phoneNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_teacher);
        initialize();
    }

    private void initialize() {
        editTextLoginActivityNewTeacher = findViewById(R.id.edit_text_login_activity_new_teacher);
        editTextPasswordActivityNewTeacher = findViewById(R.id.edit_text_password_activity_new_teacher);
        editTextNameActivityNewTeacher = findViewById(R.id.edit_text_name_activity_new_teacher);
        editTextSubjectActivityNewTeacher = findViewById(R.id.edit_text_subject_activity_new_teacher);
        editTextEmailActivityNewTeacher = findViewById(R.id.edit_text_email_activity_new_teacher);
        editTextPhoneNoActivityNewTeacher = findViewById(R.id.edit_text_phone_no_activity_new_teacher);
        buttonSubmitActivityNewTeacher = findViewById(R.id.button_submit_activity_new_teacher);
        buttonSubmitActivityNewTeacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login = editTextLoginActivityNewTeacher.getText().toString();
                password = editTextPasswordActivityNewTeacher.getText().toString();
                name = editTextNameActivityNewTeacher.getText().toString();
                subject = editTextSubjectActivityNewTeacher.getText().toString();
                email = editTextEmailActivityNewTeacher.getText().toString();
                phoneNo = editTextPhoneNoActivityNewTeacher.getText().toString();
                if (login.isEmpty() || password.isEmpty() || name.isEmpty() || subject.isEmpty() || email.isEmpty() || phoneNo.isEmpty()) {
                    Toast.makeText(NewTeacherActivity.this, "Please Fill Required Fields.", Toast.LENGTH_LONG).show();
                } else {
                    AppDatabase appDatabase = AppDatabase.getInstance(NewTeacherActivity.this);
                    User user = new User();
                    user.setLogin(login);
                    user.setPassword(password);
                    user.setType((short) 2);
                    long lastInsertId = appDatabase.userDao().addNewUser(user);
                    if (lastInsertId > 0) {
                        Teacher teacher = new Teacher();
                        teacher.setName(name);
                        teacher.setSubject(subject);
                        teacher.setEmail(email);
                        teacher.setPhoneNo(phoneNo);
                        teacher.setUserId(lastInsertId);
                        lastInsertId = appDatabase.teacherDao().addNewTeacher(teacher);
                        if (lastInsertId > 0) {
                            Toast.makeText(NewTeacherActivity.this, "New Teacher Added.", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(NewTeacherActivity.this, "Can't Add New Teacher.", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(NewTeacherActivity.this, "Can't Add New Teacher.", Toast.LENGTH_LONG).show();
                    }
                    finish();
                }
            }
        });
    }
}
