package pk.edu.pucit.lab05;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import pk.edu.pucit.lab05.entity.Student;
import pk.edu.pucit.lab05.entity.User;

public class StudentActivity extends AppCompatActivity {

    private TextView textViewLoginActivityStudent, textViewNameActivityStudent, textViewFatherNameActivityStudent, textViewRollNoActivityStudent, textViewPhoneNoActivityStudent;
    String login, name, fatherName, rollNo, phoneNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        initialize();
        setView();
    }

    private void initialize() {
        textViewLoginActivityStudent = findViewById(R.id.text_view_login_activity_student);
        textViewNameActivityStudent = findViewById(R.id.text_view_name_activity_student);
        textViewFatherNameActivityStudent = findViewById(R.id.text_view_father_name_activity_student);
        textViewRollNoActivityStudent = findViewById(R.id.text_view_roll_no_activity_student);
        textViewPhoneNoActivityStudent = findViewById(R.id.text_view_phone_no_activity_student);
    }

    private void setView() {
        Bundle bundle = getIntent().getExtras();
        User user = (User) bundle.getSerializable("user");
        Student student = (Student) bundle.getSerializable("student");
        if (user != null && student != null) {
            login = user.getLogin();
            name = student.getName();
            fatherName = student.getFatherName();
            rollNo = student.getRollNo();
            phoneNo = student.getPhoneNo();
            if (login.isEmpty() || name.isEmpty() || fatherName.isEmpty() || rollNo.isEmpty() || phoneNo.isEmpty()) {
                Toast.makeText(this, "No Data Available.", Toast.LENGTH_LONG).show();
            } else {
                textViewLoginActivityStudent.append(login);
                textViewNameActivityStudent.append(name);
                textViewFatherNameActivityStudent.append(fatherName);
                textViewRollNoActivityStudent.append(rollNo);
                textViewPhoneNoActivityStudent.append(phoneNo);
            }
        } else {
            Toast.makeText(this, "No Data Available.", Toast.LENGTH_LONG).show();
        }
    }

}
