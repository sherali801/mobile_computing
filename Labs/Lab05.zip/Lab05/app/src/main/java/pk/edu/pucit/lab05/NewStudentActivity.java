package pk.edu.pucit.lab05;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import pk.edu.pucit.lab05.database.AppDatabase;
import pk.edu.pucit.lab05.entity.Student;
import pk.edu.pucit.lab05.entity.User;

public class NewStudentActivity extends AppCompatActivity {

    private EditText editTextLoginActivityNewStudent, editTextPasswordActivityNewStudent, editTextNameActivityNewStudent, editTextFatherNameActivityNewStudent, editTextRollNoActivityNewStudent, editTextPhoneNoActivityNewStudent;
    private Button buttonSubmitActivityNewStudent;
    private String login, password, name, fatherName, rollNo, phoneNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_student);
        initialize();
    }

    private void initialize() {
        editTextLoginActivityNewStudent = findViewById(R.id.edit_text_login_activity_new_student);
        editTextPasswordActivityNewStudent = findViewById(R.id.edit_text_password_activity_new_student);
        editTextNameActivityNewStudent = findViewById(R.id.edit_text_name_activity_new_student);
        editTextFatherNameActivityNewStudent = findViewById(R.id.edit_text_father_name_activity_new_student);
        editTextRollNoActivityNewStudent = findViewById(R.id.edit_text_roll_no_activity_new_student);
        editTextPhoneNoActivityNewStudent = findViewById(R.id.edit_text_phone_no_activity_new_student);
        buttonSubmitActivityNewStudent = findViewById(R.id.button_submit_activity_new_student);
        buttonSubmitActivityNewStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login = editTextLoginActivityNewStudent.getText().toString();
                password = editTextPasswordActivityNewStudent.getText().toString();
                name = editTextNameActivityNewStudent.getText().toString();
                fatherName = editTextFatherNameActivityNewStudent.getText().toString();
                rollNo = editTextRollNoActivityNewStudent.getText().toString();
                phoneNo = editTextPhoneNoActivityNewStudent.getText().toString();
                if (login.isEmpty() || password.isEmpty() || name.isEmpty() || fatherName.isEmpty() || rollNo.isEmpty() || phoneNo.isEmpty()) {
                    Toast.makeText(NewStudentActivity.this, "Please Fill Required Fields.", Toast.LENGTH_LONG).show();
                } else {
                    AppDatabase appDatabase = AppDatabase.getInstance(NewStudentActivity.this);
                    User user = new User();
                    user.setLogin(login);
                    user.setPassword(password);
                    user.setType((short) 3);
                    long lastInsertId = appDatabase.userDao().addNewUser(user);
                    if (lastInsertId > 0) {
                        Student student = new Student();
                        student.setName(name);
                        student.setFatherName(fatherName);
                        student.setRollNo(rollNo);
                        student.setPhoneNo(phoneNo);
                        student.setUserId(lastInsertId);
                        lastInsertId = appDatabase.studentDao().addNewStudent(student);
                        if (lastInsertId > 0) {
                            Toast.makeText(NewStudentActivity.this, "New Student Added.", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(NewStudentActivity.this, "Can't Add New Student.", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(NewStudentActivity.this, "Can't Add New Student.", Toast.LENGTH_LONG).show();
                    }
                    finish();
                }
            }
        });
    }

}
