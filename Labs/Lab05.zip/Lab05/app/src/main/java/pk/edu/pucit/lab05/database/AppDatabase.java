package pk.edu.pucit.lab05.database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import pk.edu.pucit.lab05.dao.AdminDao;
import pk.edu.pucit.lab05.dao.StudentDao;
import pk.edu.pucit.lab05.dao.TeacherDao;
import pk.edu.pucit.lab05.dao.UserDao;
import pk.edu.pucit.lab05.entity.Admin;
import pk.edu.pucit.lab05.entity.Student;
import pk.edu.pucit.lab05.entity.Teacher;
import pk.edu.pucit.lab05.entity.User;

@Database(entities = {Admin.class, User.class, Student.class, Teacher.class}, version = 4)
public abstract class AppDatabase extends RoomDatabase {

    private static final String DATABASE_NAME = "app_database";
    private static AppDatabase instance = null;

    public abstract UserDao userDao();

    public abstract AdminDao adminDao();

    public abstract TeacherDao teacherDao();

    public abstract StudentDao studentDao();

    public static AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, DATABASE_NAME)
                    .allowMainThreadQueries()
                    .build();
        }
        return instance;
    }

}
