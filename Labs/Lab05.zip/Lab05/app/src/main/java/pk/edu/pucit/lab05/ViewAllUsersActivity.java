package pk.edu.pucit.lab05;

import android.arch.lifecycle.Observer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

import pk.edu.pucit.lab05.database.AppDatabase;
import pk.edu.pucit.lab05.entity.Student;
import pk.edu.pucit.lab05.entity.Teacher;

public class ViewAllUsersActivity extends AppCompatActivity {

    private ScrollView scrollViewTeachersActivityViewAllUsers, scrollViewStudentsActivityViewAllUsers;
    private TextView textViewTeachersActivityViewAllUsers, textViewStudentsActivityViewAllUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_users);
        initialize();
        setView();
    }

    private void setView() {
        setTeacherViews();
        setStudentViews();
    }

    private void initialize() {
        scrollViewTeachersActivityViewAllUsers = findViewById(R.id.scroll_view_teachers_activity_view_all_users);
        scrollViewStudentsActivityViewAllUsers = findViewById(R.id.scroll_view_students_activity_view_all_users);
        textViewTeachersActivityViewAllUsers = findViewById(R.id.text_view_teachers_activity_view_all_users);
        textViewStudentsActivityViewAllUsers = findViewById(R.id.text_view_students_activity_view_all_users);
    }

    private void setTeacherViews() {
        AppDatabase appDatabase = AppDatabase.getInstance(this);
        appDatabase.teacherDao().getAllTeachers().observe(this, new Observer<List<Teacher>>() {
            @Override
            public void onChanged(@Nullable List<Teacher> teachers) {
                textViewTeachersActivityViewAllUsers.setText("");
                for (Teacher teacher: teachers) {
                    textViewTeachersActivityViewAllUsers.append(teacher.getName() + "\n");
                }
            }
        });
    }

    private void setStudentViews() {
        AppDatabase appDatabase = AppDatabase.getInstance(this);
        appDatabase.studentDao().getAllStudents().observe(this, new Observer<List<Student>>() {
            @Override
            public void onChanged(@Nullable List<Student> students) {
                textViewStudentsActivityViewAllUsers.setText("");
                for (Student student : students) {
                    textViewStudentsActivityViewAllUsers.append(student.getName() + "\n");
                }
            }
        });
    }

}
