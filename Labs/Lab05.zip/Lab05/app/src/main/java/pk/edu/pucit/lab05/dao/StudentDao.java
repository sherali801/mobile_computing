package pk.edu.pucit.lab05.dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import java.util.List;

import pk.edu.pucit.lab05.entity.Student;

@Dao
public interface StudentDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addNewStudent(Student student);

    @Query("SELECT * FROM student s, user u WHERE s.user_id = u.id AND u.id = :userId")
    Student getStudentByUserId(long userId);

    @Query("SELECT * FROM student")
    LiveData<List<Student>> getAllStudents();

    @Query("DELETE FROM student")
    void deleteAll();

}
