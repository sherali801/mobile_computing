package pk.edu.pucit.lab05.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import pk.edu.pucit.lab05.entity.User;

@Dao
public interface UserDao {

    @Query("SELECT * FROM user WHERE login = :login AND password = :password")
    User getUserByLoginAndPassword(String login, String password);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addNewUser(User user);

    @Query("DELETE FROM user")
    void deleteAll();

}
