package pk.edu.pucit.lab05;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import pk.edu.pucit.lab05.entity.Teacher;
import pk.edu.pucit.lab05.entity.User;

public class TeacherActivity extends AppCompatActivity {

    private TextView textViewLoginActivityTeacher, textViewNameActivityTeacher, textViewSubjectActivityTeacher, textViewEmailActivityTeacher, textViewPhoneNoActivityTeacher;
    String login, name, subject, email, phoneNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher);
        initialize();
        setView();
    }

    private void initialize() {
        textViewLoginActivityTeacher = findViewById(R.id.text_view_login_activity_teacher);
        textViewNameActivityTeacher = findViewById(R.id.text_view_name_activity_teacher);
        textViewSubjectActivityTeacher = findViewById(R.id.text_view_subject_activity_teacher);
        textViewEmailActivityTeacher = findViewById(R.id.text_view_email_activity_teacher);
        textViewPhoneNoActivityTeacher = findViewById(R.id.text_view_phone_no_activity_teacher);
    }

    private void setView() {
        Bundle bundle = getIntent().getExtras();
        User user = (User) bundle.getSerializable("user");
        Teacher teacher = (Teacher) bundle.getSerializable("teacher");
        if (user != null && teacher != null) {
            login = user.getLogin();
            name = teacher.getName();
            subject = teacher.getSubject();
            email = teacher.getEmail();
            phoneNo = teacher.getPhoneNo();
            if (login.isEmpty() || name.isEmpty() || subject.isEmpty() || email.isEmpty() || phoneNo.isEmpty()) {
                Toast.makeText(this, "No Data Available.", Toast.LENGTH_LONG).show();
            } else {
                textViewLoginActivityTeacher.append(login);
                textViewNameActivityTeacher.append(name);
                textViewSubjectActivityTeacher.append(subject);
                textViewEmailActivityTeacher.append(email);
                textViewPhoneNoActivityTeacher.append(phoneNo);
            }
        } else {
            Toast.makeText(this, "No Data Available.", Toast.LENGTH_LONG).show();
        }
    }

}
