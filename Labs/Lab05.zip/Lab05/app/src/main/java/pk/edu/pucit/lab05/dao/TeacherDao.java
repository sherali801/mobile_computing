package pk.edu.pucit.lab05.dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import java.util.List;

import pk.edu.pucit.lab05.entity.Teacher;

@Dao
public interface TeacherDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addNewTeacher(Teacher teacher);

    @Query("SELECT * FROM teacher t, user u WHERE t.user_id = u.id AND u.id = :userId")
    Teacher getTeacherByUserId(long userId);

    @Query("SELECT * FROM teacher")
    public LiveData<List<Teacher>> getAllTeachers();

    @Query("DELETE FROM teacher")
    void deleteAll();

}
