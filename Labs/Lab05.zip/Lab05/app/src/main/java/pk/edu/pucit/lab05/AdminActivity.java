package pk.edu.pucit.lab05;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class AdminActivity extends AppCompatActivity implements View.OnClickListener {

    private Button buttonViewAllUsersActivityAdmin, buttonAddNewTeacherActivityAdmin, buttonAddNewStudentActivityAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        initialize();
    }

    private void initialize() {
        buttonViewAllUsersActivityAdmin = findViewById(R.id.button_view_all_users_activity_admin);
        buttonAddNewTeacherActivityAdmin = findViewById(R.id.button_add_new_teacher_activity_admin);
        buttonAddNewStudentActivityAdmin = findViewById(R.id.button_add_new_student_activity_admin);
        buttonViewAllUsersActivityAdmin.setOnClickListener(this);
        buttonAddNewTeacherActivityAdmin.setOnClickListener(this);
        buttonAddNewStudentActivityAdmin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_view_all_users_activity_admin:
                Intent intent = new Intent(this, ViewAllUsersActivity.class);
                startActivity(intent);
                break;
            case R.id.button_add_new_teacher_activity_admin:
                intent = new Intent(this, NewTeacherActivity.class);
                startActivity(intent);
                break;
            case R.id.button_add_new_student_activity_admin:
                intent = new Intent(this, NewStudentActivity.class);
                startActivity(intent);
                break;
        }
    }
}
