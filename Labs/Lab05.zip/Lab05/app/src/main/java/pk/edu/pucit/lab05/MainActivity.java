package pk.edu.pucit.lab05;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import pk.edu.pucit.lab05.database.AppDatabase;
import pk.edu.pucit.lab05.entity.Admin;
import pk.edu.pucit.lab05.entity.Student;
import pk.edu.pucit.lab05.entity.Teacher;
import pk.edu.pucit.lab05.entity.User;

public class MainActivity extends AppCompatActivity {

    private EditText editTextLoginActivityMain, editTextPasswordActivityMain;
    private Button buttonLoginActivityMain;
    private String login, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        populateData();
        initialize();
    }

    private void initialize() {
        editTextLoginActivityMain = findViewById(R.id.edit_text_login_activity_main);
        editTextPasswordActivityMain = findViewById(R.id.edit_text_password_activity_main);
        buttonLoginActivityMain = findViewById(R.id.button_login_activity_main);
        buttonLoginActivityMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login = editTextLoginActivityMain.getText().toString();
                password = editTextPasswordActivityMain.getText().toString();
                if (login.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Fill Required Fields.", Toast.LENGTH_LONG).show();
                } else {
                    AppDatabase appDatabase = AppDatabase.getInstance(MainActivity.this);
                    User user = appDatabase.userDao().getUserByLoginAndPassword(login, password);
                    if (user != null) {
                        if (user.getType() == 1) {
                            Admin admin = appDatabase.adminDao().getAdminByUserId(user.getId());
                            Intent intent = new Intent(MainActivity.this, AdminActivity.class);
                            intent.putExtra("user", user);
                            intent.putExtra("admin", admin);
                            startActivity(intent);
                        } else if (user.getType() == 2) {
                            Teacher teacher = appDatabase.teacherDao().getTeacherByUserId(user.getId());
                            Intent intent = new Intent(MainActivity.this, TeacherActivity.class);
                            intent.putExtra("user", user);
                            intent.putExtra("teacher", teacher);
                            startActivity(intent);
                        } else if (user.getType() == 3) {
                            Student student = appDatabase.studentDao().getStudentByUserId(user.getId());
                            Intent intent = new Intent(MainActivity.this, StudentActivity.class);
                            intent.putExtra("user", user);
                            intent.putExtra("student", student);
                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivity.this, "Login/Password does not match.", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Login/Password does not match.", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    private void populateData() {
        AppDatabase appDatabase = AppDatabase.getInstance(this);
        appDatabase.adminDao().deleteAll();
        User user = new User();
        user.setLogin("admin");
        user.setPassword("admin");
        user.setType((short) 1);
        long lastInsertId = appDatabase.userDao().addNewUser(user);
        if (lastInsertId > 0) {
            Admin admin = new Admin();
            admin.setName("Sher Ali");
            admin.setUserId(lastInsertId);
            lastInsertId = appDatabase.adminDao().addNewAdmin(admin);
            if (lastInsertId > 0) {
                Toast.makeText(this, "New Admin Added.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Can't Add New Admin.", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Can't Add New Admin.", Toast.LENGTH_LONG).show();
        }
    }

}
