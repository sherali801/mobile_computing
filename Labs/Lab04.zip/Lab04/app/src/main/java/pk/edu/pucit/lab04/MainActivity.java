package pk.edu.pucit.lab04;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView textViewPreviousExpenseActivityMain;
    private EditText editTextFoodActivityMain, editTextShoppingActivityMain, editTextFuelActivityMain, editTextTelephoneActivityMain;
    private double food, shopping, fuel, telephone, totalExpense;
    private String previousExpense;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor sharedPreferencesEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
        displayPreviousExpense();
    }

    private void displayPreviousExpense() {
        previousExpense = sharedPreferences.getString("total_expense", "");
        if (!previousExpense.isEmpty()) {
            textViewPreviousExpenseActivityMain.setText("Your previous expense was: " + previousExpense);
        }
    }

    private void initialize() {
        textViewPreviousExpenseActivityMain = findViewById(R.id.text_view_previous_expense_activity_main);
        editTextFoodActivityMain = findViewById(R.id.edit_text_food_activity_main);
        editTextShoppingActivityMain = findViewById(R.id.edit_text_shopping_activity_main);
        editTextFuelActivityMain = findViewById(R.id.edit_text_fuel_activity_main);
        editTextTelephoneActivityMain = findViewById(R.id.edit_text_telephone_activity_main);
        sharedPreferences = getSharedPreferences("expense_calculator", MODE_PRIVATE);
        sharedPreferencesEditor = sharedPreferences.edit();
    }

    public void calculateExpense(View view) {
        food = Double.parseDouble(editTextFoodActivityMain.getText().toString());
        shopping = Double.parseDouble(editTextShoppingActivityMain.getText().toString());
        fuel = Double.parseDouble(editTextFuelActivityMain.getText().toString());
        telephone = Double.parseDouble(editTextTelephoneActivityMain.getText().toString());
        totalExpense = food + shopping + fuel + telephone;
        Toast.makeText(this, "Your total expense is: " + String.valueOf(totalExpense), Toast.LENGTH_LONG).show();
        sharedPreferencesEditor.putString("total_expense", String.valueOf(totalExpense));
        sharedPreferencesEditor.apply();
    }
}
