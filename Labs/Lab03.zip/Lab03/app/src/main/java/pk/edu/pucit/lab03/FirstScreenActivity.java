package pk.edu.pucit.lab02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FirstScreenActivity extends AppCompatActivity implements View.OnClickListener {

    private Button send;
    private EditText name, email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_screen);

        name = findViewById(R.id.name_first_screen);
        email = findViewById(R.id.email_first_screen);

        send = findViewById(R.id.send_first_screen);
        send.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Boolean error = false;
        Intent i = new Intent(this, SecondScreenActivity.class);
        String n, e;
        n = name.getText().toString();
        if (n.isEmpty() ) {
            Toast.makeText(getApplicationContext(), "Name can't be empty", Toast.LENGTH_LONG).show();
            error = true;
        }
        e = email.getText().toString();
        if (e.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Email can't be empty", Toast.LENGTH_LONG).show();
            error = true;
        }
        if (error == true) {
            return;
        }
        i.putExtra("name", n);
        i.putExtra("email", e);
        startActivity(i);
    }
}
